﻿

// Azure Functions .NET isolated host bootstrap.
// Loads environment variables (incl. local.settings.json when run via func host)
// and wires up dependency injection if you add custom services later.