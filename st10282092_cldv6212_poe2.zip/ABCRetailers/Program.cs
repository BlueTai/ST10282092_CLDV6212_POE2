// Program.cs
using ABCRetailers.Services;
using Microsoft.AspNetCore.Http.Features;
using Microsoft.AspNetCore.Localization;
using System.Globalization;

var builder = WebApplication.CreateBuilder(args);

// MVC
builder.Services.AddControllersWithViews();

// Typed HttpClient for your Azure Functions
builder.Services.AddHttpClient<IFunctionsApi, FunctionsApiClient>((sp, client) =>
{
    var cfg = sp.GetRequiredService<IConfiguration>();
    var baseUrl = cfg["Functions:BaseUrl"] ?? throw new InvalidOperationException("Functions:BaseUrl missing");
    client.BaseAddress = new Uri(baseUrl.TrimEnd('/') + "/api/"); // adjust if your Functions don't use /api
    client.Timeout = TimeSpan.FromSeconds(100);
});

// Optional: allow larger multipart uploads (images, proofs, etc.)
builder.Services.Configure<FormOptions>(o =>
{
    o.MultipartBodyLengthLimit = 50 * 1024 * 1024; // 50 MB
});

var app = builder.Build();

// Configure the request localization options
var supportedCultures = new[] { new CultureInfo("en-US") };
app.UseRequestLocalization(new RequestLocalizationOptions
{
    DefaultRequestCulture = new RequestCulture("en-US"),
    SupportedCultures = supportedCultures,
    SupportedUICultures = supportedCultures
});

// Pipeline
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();
app.UseRouting();
app.UseAuthorization();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");

app.Run();
var host = new HostBuilder()
    .ConfigureAppConfiguration((ctx, cfg) =>
    {
        // Order: existing providers (JSON from local.settings when running locally) + env vars
        cfg.AddEnvironmentVariables();
    })
    .ConfigureAppConfiguration(_ =>
    {
        // Customize middlewares, JSON options, etc., here if needed.
    })
    .ConfigureServices(services =>
    {
        // You can register additional typed clients / services here, e.g.:
        // services.AddHttpClient("SomeApi", c => { c.BaseAddress = new Uri("https://example.com"); });
    })
    .ConfigureLogging(logging =>
    {
        logging.SetMinimumLevel(LogLevel.Information);
    })
    .Build();

await host.RunAsync();
